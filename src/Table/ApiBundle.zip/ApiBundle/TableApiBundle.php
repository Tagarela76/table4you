<?php

namespace Table\ApiBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TableApiBundle extends Bundle
{
}
